
  package com.exceptions;
  
  public class InValidModelNumberException extends Exception { public
  InValidModelNumberException(String message) { super(message); }
  
  }
 