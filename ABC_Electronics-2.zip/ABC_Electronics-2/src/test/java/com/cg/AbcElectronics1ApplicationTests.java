package com.cg;

import org.junit.jupiter.api.Test;
class NewAbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
